import 'homepage.dart' as homepage;

void main() => homepage.main();
